package assignments;


/**
 * 
 * NAME：Xinyi Wu
 * @version1
 */

public class TransportBoat extends Boat{ 
    private int height,width,length;

    public TransportBoat() {}

    
    public TransportBoat(String name, double x, double y, double heading, double speed, double loadCapacity, double batteryCapacity, int height, int width, int length) {
        
        super(name, x, y, heading, speed, loadCapacity, batteryCapacity);
        this.height = height;
        this.width = width;
        this.length = length;
    }
    
    public int calArea(){
        return width*length;
    }
    
    public void output(){
        
        super.output();
        System.out.println("Boat Height:"+height);
        System.out.println("Boat Width:"+width);
        System.out.println("Boat Length:"+length);
    }

    public static void main(String[] args) {
        TransportBoat transportBoat=new TransportBoat("boat1",3,4,30,15,100,100,1,2,3);
        transportBoat.output();
        System.out.println(transportBoat.calArea());
    }
}
