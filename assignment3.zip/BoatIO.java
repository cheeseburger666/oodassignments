package assignments;


/**
 * 
 * NAME：Xinyi Wu
 * @version1
 */


import java.io.*;
import java.util.ArrayList;
import java.util.List;

public class BoatIO {
    
    private void save(Boat boat,String fileName){
        try {
            
            File file=new File("D:\\"+fileName);
            if(!file.exists()){
                file.createNewFile();
            }
            
            
            FileOutputStream fos=new FileOutputStream(file);
            ObjectOutputStream oos=new ObjectOutputStream(fos);
            oos.writeObject(boat);
            
            oos.close();
            fos.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    
    public void save(List<Boat> list,String fileName){
        try {
            
            File file=new File("D:\\"+fileName);
            if(!file.exists()){
                file.createNewFile();
            }
            FileOutputStream fos=new FileOutputStream(file);
            ObjectOutputStream oos=new ObjectOutputStream(fos);
            oos.writeObject(list);
            
            oos.close();
            fos.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public List load(List<Boat> list,String fileName){
        
        File file=new File("D:\\"+fileName);
        try {
            FileInputStream fis=new FileInputStream(file);
            ObjectInputStream ois=new ObjectInputStream(fis);
            list=(List)ois.readObject();
            
            ois.close();
            fis.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return list;
    }

    public static void main(String[] args) {
        TransportBoat transportBoat=new TransportBoat("boat1",3,4,30,15,100,100,1,2,3);
        BoatIO boatIO=new BoatIO();
        List<Boat> list=new ArrayList<>();
        list.add(transportBoat);
        boatIO.save(transportBoat,"boat1");
        boatIO.save(list,"boat2");
        List<Boat> list1=boatIO.load(list,"boat2");
        list.forEach(b-> b.output());
    }
}
